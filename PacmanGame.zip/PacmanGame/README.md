# Pacman
a simple java game using swing also with Map Editor and Map Compiler

![Alt text](/../master/pacman.png?raw=true "Screenshot")
