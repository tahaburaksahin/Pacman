import java.awt.*;
public class Food {

    public Point position;

    public Food(int x,int y){
        position = new Point(x,y);
    }

}
