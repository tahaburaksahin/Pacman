import java.awt.*;

public class Messeges {

    public static final int UPDATE = AWTEvent.RESERVED_ID_MAX + 1;
    public static final int COLTEST = AWTEvent.RESERVED_ID_MAX + 2;
    public static final int RESET = AWTEvent.RESERVED_ID_MAX + 3;


}
