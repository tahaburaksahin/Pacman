public enum ghostType{
    RED,
    PINK,
    CYAN
}