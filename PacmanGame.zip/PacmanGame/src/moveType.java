public enum moveType{
    NONE,
    UP,
    DOWN,
    LEFT,
    RIGHT
}
